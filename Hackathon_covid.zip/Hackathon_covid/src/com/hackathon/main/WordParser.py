import json
import sys
import matplotlib.pyplot as plt
import pandas as pd
import pandasql as psql
import nltk
import string
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
nltk.download('punkt')
nltk.download('wordnet')
from nltk.stem import WordNetLemmatizer

from geotext import GeoText


lemmatizer = WordNetLemmatizer()

covidDF = None

#Reading in the corpus
with open('../../../../resource/covid_chatbot.txt', 'r', encoding='utf8', errors ='ignore') as fin:
    raw = fin.read().lower()

#TOkenisation
sent_tokens = nltk.sent_tokenize(raw)# converts to list of sentences
word_tokens = nltk.word_tokenize(raw)# converts to list of words

# Preprocessing
lemmer = WordNetLemmatizer()
def LemTokens(tokens):
    return [lemmer.lemmatize(token) for token in tokens]
remove_punct_dict = dict((ord(punct), None) for punct in string.punctuation)
def LemNormalize(text):
    return LemTokens(nltk.word_tokenize(text.lower().translate(remove_punct_dict)))

def loadCovidData():
    covidDF = pd.read_csv("../../../../resource/covid-data.csv")
    return covidDF

def loadDict():
    lookup_dict = json.loads(open("../../../../resource/intents.json").read())
    return lookup_dict

def parseRequest(user_response):
    robo_response=''
    sent_tokens.append(user_response)
    TfidfVec = TfidfVectorizer(tokenizer=LemNormalize, stop_words='english')
    tfidf = TfidfVec.fit_transform(sent_tokens)
    vals = cosine_similarity(tfidf[-1], tfidf)
    idx=vals.argsort()[0][-2]
    flat = vals.flatten()
    flat.sort()
    req_tfidf = flat[-2]
    if(req_tfidf==0):
        robo_response=robo_response+"I am sorry! I don't understand you"
        return robo_response
    else:
        robo_response = robo_response+sent_tokens[idx]
        return robo_response



def parseQuestion(question):
    covidDF = loadCovidData()
    # query = """ SELECT location, sum(total_cases) as total_cases FROM covidDF GROUP BY location"""
    # places = GeoText("London is a great city. I like Leeds.")
    places = GeoText(question)
    country_conditions = str(places.countries).strip('[]')
    print("========: ",country_conditions)
    query_key = parseRequest(question).replace("?", "").replace(" ", "_")
    query_key = str(query_key).split("\n")[1]
    query_key = query_key.replace(".", "")
    print("Query Key: ",query_key)
    intents = loadDict()
    query = intents[query_key]
    print("Query: ", query)

    if(country_conditions is None or len(country_conditions) == 0):
        resultDF = psql.sqldf(query, locals())
    else:
        resultDF = psql.sqldf("SELECT * FROM("+query+") WHERE location in("+country_conditions+")", locals())

    # resultDF.to_json(r'C:\\Ashish\\Accenture\\NDAS\\projects\\python\\Hackathon_covid\\output\\covid-result.json')
    print(resultDF)
    print(len(resultDF.index))
    if((len(resultDF.index)) > 1):
        columns = resultDF.columns
        resultDF.plot(kind='bar', x=columns[0], y=columns[1])
        plt.show()



if __name__ == '__main__':
    question = sys.argv[1]
    if(question is not None):
        print("Question: " + question)
        parseQuestion(question)
    else:
        print("Pass an argument")
